// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

namespace AdtExplorer.Functions.Configuration
{
  public class EndpointOptions
  {
    public bool UseLocalAuth { get; set; }
  }
}
